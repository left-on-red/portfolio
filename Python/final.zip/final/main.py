import pygame
import playfield

field = playfield.playfield()
field.start()